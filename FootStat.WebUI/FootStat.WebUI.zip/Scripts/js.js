﻿$(document).ready(function() {
    $('.menuButton').click(function() {
        $('nav').slideToggle("slow");
    });
})
